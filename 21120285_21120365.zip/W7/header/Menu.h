#ifndef MENU_H
#define MENU_H

#include "../header/Trie.h"

void ShowMenu();
void Command1(TrieNode* &Dic);
void Command2(TrieNode* Dic);
void Command3(TrieNode* Dic);
void Command4(TrieNode* Dic);

#endif
#include "../header/Menu.h"

using namespace std;

int main() {
    ShowMenu();

    return 0;
}
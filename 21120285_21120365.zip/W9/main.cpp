#include "./CommandProcess.h"

#include <iostream>

int main(int argc, char** argv) {
    CommandProcess(argc, argv);

    return 0;
}
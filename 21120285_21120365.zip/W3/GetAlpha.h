#ifndef GET_ALPHA_H
#define GET_ALPHA_H

int isLess(int a, int b);
int isGreater(int a, int b) ;
int findGCD(int a, int b);

#endif
#include "./CommandProcess.h"

int main(int argc, char** argv) {
    CommandProcess(argc, argv);

    return 0;
}
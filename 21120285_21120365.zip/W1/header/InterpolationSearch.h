#ifndef INTERPOLATION_SEARCH_H
#define INTERPOLATION_SEARCH_H

int InterpolationSearch(int a[], int n, int k, int& loopCount);

#endif
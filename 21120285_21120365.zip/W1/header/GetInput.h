#ifndef GET_ARRAY_H
#define GET_ARRAY_H

void GetInput(int argc, char** argv, int* &a, int &n, int &k);

#endif